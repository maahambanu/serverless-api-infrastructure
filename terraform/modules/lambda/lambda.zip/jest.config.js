module.exports = {
  testEnvironment: "node"
};